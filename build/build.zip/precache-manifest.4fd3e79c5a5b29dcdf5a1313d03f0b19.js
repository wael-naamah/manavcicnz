self.__precacheManifest = [
  {
    "revision": "fb523c018a8d528c2fe69cc446510e48",
    "url": "/static/media/vegetables.fb523c01.jpeg"
  },
  {
    "revision": "6fa50c1447e42455decd",
    "url": "/static/css/main.5ff58821.chunk.css"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "594786c8483f84db286a8629baab3350",
    "url": "/static/media/8.594786c8.jpg"
  },
  {
    "revision": "3d17bd35b25ce27b8bc7",
    "url": "/static/js/2.8e6d7282.chunk.js"
  },
  {
    "revision": "39da99905ed436e8d24c073250a2be77",
    "url": "/static/media/loginimage.39da9990.png"
  },
  {
    "revision": "1b585845b42d5a41ae781bd75777249b",
    "url": "/static/media/empty-cart-img.1b585845.png"
  },
  {
    "revision": "c60fea3ac3aab2e82c2f7ea901ef55f6",
    "url": "/static/media/empty-cart.c60fea3a.jpg"
  },
  {
    "revision": "6fa50c1447e42455decd",
    "url": "/static/js/main.47dc7bc3.chunk.js"
  },
  {
    "revision": "d1f767ad6460bf4f35c7b50a19d2e443",
    "url": "/static/media/green2.d1f767ad.jpg"
  },
  {
    "revision": "aacfa4ce48a26cfb820d7745621c173c",
    "url": "/static/media/fruit.aacfa4ce.jpg"
  },
  {
    "revision": "9de9d0d3d04bde7264e125adf8d7e816",
    "url": "/static/media/3.9de9d0d3.jpg"
  },
  {
    "revision": "b5e811e4753e434106b3358df5f81bf3",
    "url": "/static/media/5.b5e811e4.jpg"
  },
  {
    "revision": "dc1c66604930c3c5789bc38310d9773f",
    "url": "/static/media/6.dc1c6660.jpg"
  },
  {
    "revision": "bdfb6576b827fcfd339434baba004e94",
    "url": "/static/media/7.bdfb6576.jpg"
  },
  {
    "revision": "3d17bd35b25ce27b8bc7",
    "url": "/static/css/2.2f300a2b.chunk.css"
  },
  {
    "revision": "68d3bd26ae8d1f8446f337e9b8eb558f",
    "url": "/index.html"
  }
];